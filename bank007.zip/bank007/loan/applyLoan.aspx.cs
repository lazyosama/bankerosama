﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projbm
{
    public partial class applyLoan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MultiViewloan.ActiveViewIndex = 0;
            }
            if (dd_loanType.Text == "Home/Personal")
            {
                lbl_roi_automatic.Text = "12%";
            }
            else
            {
                lbl_roi_automatic.Text = "10%";

            }

        }

        protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
        {

        }

        protected void img_loansub_Click(object sender, ImageClickEventArgs e)
        {
            if (dd_loanType.Text == "Home/Personal")
            {
                MultiViewloan.ActiveViewIndex = 1;
            }
            else
            {
                MultiViewloan.ActiveViewIndex = 2;

            }
            }
    }
}